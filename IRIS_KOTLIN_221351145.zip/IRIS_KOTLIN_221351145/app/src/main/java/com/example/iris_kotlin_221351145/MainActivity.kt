package com.example.iris_kotlin_221351145

import android.content.res.AssetManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

class MainActivity : AppCompatActivity() {

    private lateinit var interpreter: Interpreter
    private val modelPath = "iris.tflite"

    private lateinit var resultText: TextView
    private lateinit var edtSepalLength: EditText
    private lateinit var edtSepalWidth: EditText
    private lateinit var edtPetalLength: EditText
    private lateinit var edtPetalWidth: EditText
    private lateinit var btnCheck: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        resultText = findViewById(R.id.txtResult)
        edtSepalLength = findViewById(R.id.edtSepalLengthCm)
        edtSepalWidth = findViewById(R.id.edtSepalWidthCm)
        edtPetalLength = findViewById(R.id.edtPetalLengthCm)
        edtPetalWidth = findViewById(R.id.edtPetalWidthCm)
        btnCheck = findViewById(R.id.btnCheck)

        btnCheck.setOnClickListener {
            val result = doInference(
                edtSepalLength.text.toString(),
                edtSepalWidth.text.toString(),
                edtPetalLength.text.toString(),
                edtPetalWidth.text.toString()
            )

            runOnUiThread {
                resultText.text = when (result) {
                    0 -> "iris-setosa"
                    1 -> "iris-versicolor"
                    2 -> "iris-virginica"
                    else -> "Unknown"
                }
            }
        }

        initInterpreter()
    }

    private fun initInterpreter() {
        val options = Interpreter.Options().apply {
            setNumThreads(5)
            setUseNNAPI(true)
        }
        interpreter = Interpreter(loadModelFile(assets, modelPath), options)
    }

    private fun doInference(
        input1: String,
        input2: String,
        input3: String,
        input4: String
    ): Int {
        val inputVal = FloatArray(4).apply {
            this[0] = input1.toFloat()
            this[1] = input2.toFloat()
            this[2] = input3.toFloat()
            this[3] = input4.toFloat()
        }

        val input = arrayOf(inputVal)
        val output = Array(1) { FloatArray(3) }

        interpreter.run(input, output)

        Log.i("result", output[0].toList().toString())

        return output[0].indexOfFirst { it == output[0].maxOrNull() }
    }

    private fun loadModelFile(assetManager: AssetManager, modelPath: String): MappedByteBuffer {
        val fileDescriptor = assetManager.openFd(modelPath)
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }
}
